# turn RTS off 
iwconfig wlan0 rts 1000 

# log route tables 
route >> concurrentFlow_gateway_udp_rtsOn_bidir_hop1_log & 

../tcpdump -i br0 -w /mnt/hd2/concurrentFlow_gateway_udp_rtsOn_bidir3_log &

echo "===== UPLOAD 1.248.64.31 UNIDIRECTIONAL FLOW========" >> concurrentFlow_gateway_udp_rtsOn_bidir_hop1_log  
../iperf -c 1.248.64.31 -u -b 10m -t 20 -p 1024 >> concurrentFlow_gateway_udp_rtsOn_bidir_hop1_log &
echo >> concurrentFlow_gateway_udp_rtsOn_bidir_hop1_log &
echo "===========================================" >> concurrentFlow_gateway_udp_rtsOn_bidir_hop1_log &
echo >> concurrentFlow_gateway_udp_rtsOn_bidir_hop1_log &

echo "===== UPLOAD 1.188.212.31 UNIDIRECTIONAL FLOW========" >> concurrentFlow_gateway_udp_rtsOn_bidir_hop2_log &
../iperf -c 1.188.212.31 -u -b 10m -t 20 -p 1024 >> concurrentFlow_gateway_udp_rtsOn_bidir_hop2_log &
echo >> concurrentFlow_gateway_udp_rtsOn_bidir_hop2_log &
echo "===========================================" >> concurrentFlow_gateway_udp_rtsOn_bidir_hop2_log &
echo >> concurrentFlow_gateway_udp_rtsOn_bidir_hop2_log &

echo "===== UPLOAD 1.93.105.236 UNIDIRECTIONAL FLOW========" >> concurrentFlow_gateway_udp_rtsOn_bidir_hop3_log &
../iperf -c 1.93.105.236 -u -b 10m -t 20 -p 1024 >> concurrentFlow_gateway_udp_rtsOn_bidir_hop3_log &
echo >> concurrentFlow_gateway_udp_rtsOn_bidir_hop3_log &
echo "===========================================" >> concurrentFlow_gateway_udp_rtsOn_bidir_hop3_log &
echo >> concurrentFlow_gateway_udp_rtsOn_bidir_hop3_log &

echo "===== UPLOAD 1.70.18.140 UNIDIRECTIONAL FLOW========" >> concurrentFlow_gateway_udp_rtsOn_bidir_hop4_log &
../iperf -c 1.70.18.140 -u -b 10m -t 20 -p 1024 >> concurrentFlow_gateway_udp_rtsOn_bidir_hop4_log &
echo >> concurrentFlow_gateway_udp_rtsOn_bidir_hop4_log &
echo "===========================================" >> concurrentFlow_gateway_udp_rtsOn_bidir_hop4_log &

pause 30
killall tcpdump >> concurrentFlow_gateway_udp_rtsOn_bidir_hop1_log
 
