#initialization script to run on all meshboxes 

#set rate limit 
iwconfig wlan0 rate 11M 

reporter >> singleFlow_tcp_rtsOff_allnodes_log

#set up iperf servers: UDP & TCP 
../iperf -s -p 5001 >> singleFlow_tcp_rtsOff_allnodes_log

