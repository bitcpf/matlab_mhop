#get number of connections 
echo "Enter number of connections: "
read Conn 

#get number of trial 
echo "Enter number of trial: "
read Trial 

../tcpdump -i br0 -w /mnt/hd2/httperf$Conn\_$Trial & 
sleep 25
killall tcpdump 
