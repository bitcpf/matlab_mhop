# turn RTS off 
iwconfig wlan0 rts off 

# log route tables 
route >> concurrentFlow_gateway_tcp_rtsOff_hop1_log & 

echo "===== UPLOAD 1.248.64.31 BIDIRECTIONAL FLOW========" >> concurrentFlow_gateway_tcp_rtsOff_hop1_log  
../iperf -c 1.248.64.31 -t 20 >> concurrentFlow_gateway_tcp_rtsOff_hop1_log &
echo >> concurrentFlow_gateway_tcp_rtsOff_hop1_log &
echo "===========================================" >> concurrentFlow_gateway_tcp_rtsOff_hop1_log &
echo >> concurrentFlow_gateway_tcp_rtsOff_hop1_log &

echo "===== UPLOAD 1.188.212.31 BIDIRECTIONAL FLOW========" >> concurrentFlow_gateway_tcp_rtsOff_hop2_log &
../iperf -c 1.188.212.31 -t 20 >> concurrentFlow_gateway_tcp_rtsOff_hop2_log &
echo >> concurrentFlow_gateway_tcp_rtsOff_hop2_log &
echo "===========================================" >> concurrentFlow_gateway_tcp_rtsOff_hop2_log &
echo >> concurrentFlow_gateway_tcp_rtsOff_hop2_log &

echo "===== UPLOAD 1.93.105.236 BIDIRECTIONAL FLOW========" >> concurrentFlow_gateway_tcp_rtsOff_hop3_log &
../iperf -c 1.93.105.236 -t 20 >> concurrentFlow_gateway_tcp_rtsOff_hop3_log &
echo >> concurrentFlow_gateway_tcp_rtsOff_hop3_log &
echo "===========================================" >> concurrentFlow_gateway_tcp_rtsOff_hop3_log &
echo >> concurrentFlow_gateway_tcp_rtsOff_hop3_log &

echo "===== UPLOAD 1.70.18.140 BIDIRECTIONAL FLOW========" >> concurrentFlow_gateway_tcp_rtsOff_hop4_log &
../iperf -c 1.70.18.140 -t 20 >> concurrentFlow_gateway_tcp_rtsOff_hop4_log &
echo >> concurrentFlow_gateway_tcp_rtsOff_hop4_log &
echo "===========================================" >> concurrentFlow_gateway_tcp_rtsOff_hop4_log &
 
