# turn RTS off 
iwconfig wlan0 rts off 

# log route tables 
route >> singleFlow_gateway_tcp_rtsOff_hop1_log 

echo "===== UPLOAD 1.248.64.31 UNIDIRECTIONAL FLOW========" >> singleFlow_gateway_tcp_rtsOff_hop1_log  
../iperf -c 1.248.64.31 -t 120 -i 20 >> singleFlow_gateway_tcp_rtsOff_hop1_log
echo >> singleFlow_gateway_tcp_rtsOff_hop1_log
echo "===========================================" >> singleFlow_gateway_tcp_rtsOff_hop1_log
echo >> singleFlow_gateway_tcp_rtsOff_hop1_log

echo "===== UPLOAD 1.188.212.31 UNIDIRECTIONAL FLOW========" >> singleFlow_gateway_tcp_rtsOff_hop2_log
../iperf -c 1.188.212.31 -t 120 -i 20 >> singleFlow_gateway_tcp_rtsOff_hop2_log
echo >> singleFlow_gateway_tcp_rtsOff_hop2_log
echo "===========================================" >> singleFlow_gateway_tcp_rtsOff_hop2_log
echo >> singleFlow_gateway_tcp_rtsOff_hop2_log

echo "===== UPLOAD 1.93.105.236 UNIDIRECTIONAL FLOW========" >> singleFlow_gateway_tcp_rtsOff_hop3_log
../iperf -c 1.93.105.236 -t 120 -i 20 >> singleFlow_gateway_tcp_rtsOff_hop3_log
echo >> singleFlow_gateway_tcp_rtsOff_hop3_log
echo "===========================================" >> singleFlow_gateway_tcp_rtsOff_hop3_log
echo >> singleFlow_gateway_tcp_rtsOff_hop3_log

echo "===== UPLOAD 1.70.18.140 UNIDIRECTIONAL FLOW========" >> singleFlow_gateway_tcp_rtsOff_hop4_log
../iperf -c 1.70.18.140 -t 120 -i 20 >> singleFlow_gateway_tcp_rtsOff_hop4_log
echo >> singleFlow_gateway_tcp_rtsOff_hop4_log
echo "===========================================" >> singleFlow_gateway_tcp_rtsOff_hop4_log
 
