# route tables 
route >> httperf_log

# httperf test -- users 10 - 100 

# 10 users
echo "====== 10 USERS ==========" >> httperf_log
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=30  
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=30
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=30
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=30
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=30
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=30
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=30
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=30
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=30
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=30

echo >> httperf_log 
iwspy wlan0 >> httperf_log
echo "========================" >> httperf_log 
echo >> httperf_log 

