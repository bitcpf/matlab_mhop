# turn RTS on 
iwconfig wlan0 rts 1000 
reporter >> concurrentFlow_tcp_rtsOn_download_log

# log route tables
route >> concurrentFlow_tcp_rtsOn_download_log 

# test upload of flow
echo "=========== DOWNLOAD ==============" >> concurrentFlow_tcp_rtsOn_download_log 
../iperf -c 1.241.56.218 -t 20 >> concurrentFlow_tcp_rtsOn_download_log 

echo >> concurrentFlow_tcp_rtsOn_download_log 

echo "==========================" >> concurrentFlow_tcp_rtsOn_download_log 
echo >> concurrentFlow_tcp_rtsOn_download_log 
echo >> concurrentFlow_tcp_rtsOn_download_log 
