# turn RTS off 
iwconfig wlan0 rts 1000 
reporter >> singleFlow_tcp_rtsOn_log

# log route tables 
route >> singleFlow_tcp_rtsOn_log

# test upload of singleflow 
echo "===== DOWNLOAD MULTIHOP SINGLE FLOW========" >> singleFlow_tcp_rtsOn_log  
../iperf -c 1.241.56.218 -i 20 -t 120 >> singleFlow_tcp_rtsOn_log

echo "===========================================" >> singleFlow_tcp_rtsOn_log
echo >> singleFlow_tcp_rtsOn_log 
