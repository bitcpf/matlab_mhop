# route tables 
route >> httperf_log

# httperf test -- users 10 - 100 

# 20 users 
echo "====== 20 USERS ==========" >> httperf_log
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=60
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=60
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=60
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=60
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=60
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=60
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=60
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=60
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=60
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=60  

echo >> httperf_log 
iwspy wlan0 >> httperf_log
echo "========================" >> httperf_log 
echo >> httperf_log 

