# turn RTS on 
iwconfig wlan0 rts 1000 
reporter >> concurrentFlow_udp_rtsOn_download_bidir_log

# dump route tables 
route >> concurrentFlow_udp_rtsOn_download_bidir_log 

# test upload of singleflow 
echo "============= DOWNLOAD ============" >> concurrentFlow_udp_rtsOn_download_bidir_log  

../tcpdump -i br0 -w /mnt/hd2/concurrentFlow_udp_rtsOn_download_bidir2_log &
../iperf -c 1.241.56.218 -u -b 10m -t 20 -p 1037 >> concurrentFlow_udp_rtsOn_download_bidir_log
pause 3
killall tcpdump >> concurrentFlow_udp_rtsOn_download_bidir_log

echo >> concurrentFlow_udp_rtsOn_download_bidir_log 
echo "==========================" >> concurrentFlow_udp_rtsOn_download_bidir_log
echo >> concurrentFlow_udp_rtsOn_download_bidir_log 
