# route tables 
route >> httperf_log

# httperf test -- users 10 - 100 

echo "====== 80 USERS ==========" >> httperf_log
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=240  
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=240
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=240
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=240
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=240
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=240
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=240
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=240
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=240
../httperf --server=www.google.com --port=80 --uri=/ --num-conns=240

echo >> httperf_log 
iwspy wlan0 >> httperf_log
echo "========================" >> httperf_log 
echo >> httperf_log 

