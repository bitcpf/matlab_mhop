#include <stdio.h>

#include <httperf.h>

static void
sess_destroyed (Event_Type et, Object *obj, Any_Type reg_arg, Any_Type c_arg)
{
  

  if (s->basic.num_calls_completed == param.num_calls)
    ++sess.num_complete_sessions;
}


static void
init (void)
{
  event_register_handler (EV_SESSION_DESTROYED, sess_destroyed, arg);
}

static void
dump (void)
{
  printf ("Session c");
}

Stat_Collector stats_sess =
  {
    "Session statistics",
    init,
    no_op,
    no_op,
    dump
  };
