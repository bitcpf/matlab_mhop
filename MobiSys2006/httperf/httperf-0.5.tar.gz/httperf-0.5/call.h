/*
	Copyright (C) 1997 Hewlett-Packard Company
*/
#ifndef call_h
#define call_h

#include <sys/types.h>
#include <sys/uio.h>

#include <httperf.h>
#include <conn.h>

/* The following enum *MUST* be kept in-sync with call_method_name in
   call.c.  */
typedef enum HTTP_Method
  {
    HM_DELETE,
    HM_GET,
    HM_HEAD,
    HM_OPTIONS,
    HM_POST,
    HM_PUT,
    HM_TRACE,
    HM_LEN
  }
HTTP_Method;

extern const char *call_method_name[HM_LEN];

/* Max. # of additional request header lines we allow: */
#define MAX_EXTRA_HEADERS	4

typedef enum IOV_Element
  {
    IE_METHOD,
    IE_BLANK,
    IE_LOC,		/* for proxy requests only */
    IE_URI,
    IE_PROTL,
    IE_HOST,		/* for the "Host:" header */
    IE_NEWLINE1,
    IE_FIRST_HEADER,
    IE_LAST_HEADER = IE_FIRST_HEADER + MAX_EXTRA_HEADERS - 1,
    IE_NEWLINE2,
    IE_CONTENT,
    IE_LEN		/* must be last */
  }
IOV_Element;

/* I call this a "call" because "transaction" is too long and because
   it's basically a remote procedure call consisting of a request that
   is answered by a reply.  */
typedef struct Call
  {
    Object obj;

    u_long id;			/* unique id */

    struct Conn *conn;		/* connection for this call */
    struct Call *next;
    struct Call *sendq_next;
    struct Call *recvq_next;
    Time timeout;		/* used for watchdog management */

    struct
      {
	Time time_send_start;
	Time time_recv_start;
      }
    basic;

    /* the request: */
    struct
      {
	HTTP_Method method;
	int version;		/* 0x10000*major + minor */

	size_t loc_len;
	const char *loc;	/* for proxies (e.g., "http://www.fun.com") */
	size_t uri_len;
	const char *uri;	/* e.g., "/index.html" */
	size_t orig_host_len;
	const char *orig_host;	/* e.g., www.fun.com */
	u_int num_extra_hdrs;	/* number of additional headers in use */
	struct iovec extra_hdrs[MAX_EXTRA_HEADERS];
	size_t contents_len;
	const char *contents;	/* contents of HTTP request */

	/* used by core to send request: */
	int iov_index;		/* first iov element that has data */
	struct iovec iov[IE_LEN];

	size_t size;		/* # of bytes sent */
      }
    req;

    /* the reply: */
    struct
      {
	int status;
	int version;		/* 0x10000*major + minor */
	size_t header_bytes;	/* # of header bytes received so far */
	size_t content_bytes;	/* # of reply data bytes received so far */
	size_t footer_bytes;	/* # of footer bytes received so far */
      }
    reply;
  }
Call;

extern Call *call_new (Conn *s);
extern void call_destroy (Call *c);
extern int call_append_request_header (Call *c, const char *hdr, size_t len);

#endif /* call_h */
