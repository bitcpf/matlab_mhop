/*

   Copyright (C) 1998 Hewlett-Packard Company
   ALL RIGHTS RESERVED.

   The enclosed software and documentation includes copyrighted works
   of Hewlett-Packard Co. For as long as you comply with the following
   limitations, you are hereby authorized to (i) use, reproduce, and
   modify the software and documentation, and to (ii) distribute the
   software and documentation, including modifications, for
   non-commercial purposes only.

   1.  The enclosed software and documentation is made available at no
   charge in order to advance the general development of
   high-performance networking and computing products.

   2.  You may not delete any copyright notices contained in the
   software or documentation. All hard copies, and copies in
   source code or object code form, of the software or
   documentation (including modifications) must contain at least
   one of the copyright notices.

   3.  The enclosed software and documentation has not been subjected
   to testing and quality control and is not a Hewlett-Packard Co.
   product. At a future time, Hewlett-Packard Co. may or may not
   offer a version of the software and documentation as a product.

   4.  THE SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS".
   HEWLETT-PACKARD COMPANY DOES NOT WARRANT THAT THE USE,
   REPRODUCTION, MODIFICATION OR DISTRIBUTION OF THE SOFTWARE OR
   DOCUMENTATION WILL NOT INFRINGE A THIRD PARTY'S INTELLECTUAL
   PROPERTY RIGHTS. HP DOES NOT WARRANT THAT THE SOFTWARE OR
   DOCUMENTATION IS ERROR FREE. HP DISCLAIMS ALL WARRANTIES,
   EXPRESS AND IMPLIED, WITH REGARD TO THE SOFTWARE AND THE
   DOCUMENTATION. HP SPECIFICALLY DISCLAIMS ALL WARRANTIES OF
   MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.

   5.  HEWLETT-PACKARD COMPANY WILL NOT IN ANY EVENT BE LIABLE FOR ANY
   DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES
   (INCLUDING LOST PROFITS) RELATED TO ANY USE, REPRODUCTION,
   MODIFICATION, OR DISTRIBUTION OF THE SOFTWARE OR DOCUMENTATION.

 */

/* This load generator can be used to recreate a workload based on a
   server log file.
 
   There is currently no tool that translates from standard log
   formats to the format accepted by this module.

   An example input file follows:

#
# This file specifies the potentially-bursty uri sequence for a number of
# user sessions.  The format rules of this file are as follows:
#
# Comment lines start with a '#' as the first character.  # anywhere else
# is considered part of the uri.
#
# Lines with only whitespace delimit session definitions (multiple blank
# lines do not generate "null" sessions).
#
# Lines otherwise specify a uri-sequence (1 uri per line).  If the
# first character of the line is whitespace (e.g. space or tab), the
# uri is considered to be part of a burst that is sent out after the
# previous non-burst uri.
#

# session 1 definition (this is a comment)

foo.html
	pict1.gif
	pict2.gif
foo2.html
	pict3.gif
	pict4.gif

#session 2 definition

foo3.html
foo4.html
	pict5.gif

   Any comment on this module contact carter@hpl.hp.com or
   davidm@hpl.hp.com.  */

#include <assert.h>
#include <ctype.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/types.h>

#include <httperf.h>
#include <call.h>
#include <core.h>
#include <event.h>

#include <uri_wsesslog.h>
#include <wsesslog.h>

#define TRUE  (1)
#define FALSE (0)

/*
 * There are 3 different data-types in this data-structure.  A USER_SESSION
 * contains global information about the session, including the total number
 * of requests and may eventually contain state info about the user, such
 * as frustration level, number of "stops" or "reloads", etc.  The USER_SESSION
 * also includes a pointer to the head of a BURST list.  The BURST structure
 * contains info about a burst of requests- the number of requests in the
 * burst primarily, but might in the future contain info like a burst-specific
 * user think-time.  The BURST contains a pointer to a list of REQs.
 * Each REQ includes the uri string (and string length for run-time efficiency
 * reasons).  In the future, it might include the protocol (e.g. https), the
 * method (e.g. POST) and additional request data (again for POST).
 *
 * Actually, I had a bug in my thinking when I set up the user_session info
 * in a static structure- many virtual users can be simultaneously playing
 * out a much-smaller number of user session uri-lists.  Each needs its own
 * copy of the USER_SESSION info.  Thus, we must create and destroy user_session
 * dynamically and hold on to old ones on a free list.
 */

typedef struct req REQ;
struct req {
    char *uri;
    int uri_len;
    int method;
    char *contents;
    int contents_len;
    char extra_hdrs[50];	/* plenty for "Content-length: 1234567890" */
    int extra_hdrs_len;
    REQ *next;
};

typedef struct burst BURST;
struct burst {
    int num_reqs;
    Time user_think_time;
    REQ *req_list;
    BURST *next;
};

typedef struct user_session USER_SESSION;
struct user_session {
    USER_SESSION *next;
    int total_num_reqs;
    BURST *burst_list;
    BURST *current_burst;
    REQ *current_req;
};

#define MAX_USER_SESSIONS 1000

/* this is an array rather than a list because we may want different
   httperf clients to start at different places in the sequence of sessions */
static USER_SESSION user_sessions[MAX_USER_SESSIONS] = {{ 0, }};

static int num_sessions, next_free_session, reqs_in_longest_session;
static USER_SESSION *free_user_sessions_list;

u_int
wsesslog_num_calls_longest_session()
{
    return reqs_in_longest_session;
}

u_int
wsesslog_num_calls_this_session(Sess *u)
{
    USER_SESSION *this_session;
    this_session = (USER_SESSION *) u->uri_sess.vp;

    return this_session->total_num_reqs;
}

/* when a new session gets destroyed, this function puts the 
   user session structure onto a free list for subsequent re-use */

static void
destroy_sess (Event_Type et, Object *o, Any_Type regarg, Any_Type call_arg)
{
    Sess *u;
    USER_SESSION *this_session;
    
    assert (et == EV_SESS_DESTROYED && call_arg.vp != NULL);
    
    u = call_arg.vp;
    this_session = (USER_SESSION *) u->uri_sess.vp;

    this_session->next = free_user_sessions_list;
    free_user_sessions_list = this_session;
}


/* when a new session gets created, this function registers a pointer to the
   user session info in the session structure created by wsesslog */

static void
set_sess (Event_Type et, Object *o, Any_Type regarg, Any_Type call_arg)
{
    Sess *u;
    USER_SESSION *template, *this_session;
    
    assert (et == EV_SESS_NEW && call_arg.vp != NULL);
    
    if (free_user_sessions_list) {
	this_session = free_user_sessions_list;
	free_user_sessions_list = free_user_sessions_list->next;
    }
    else {
	this_session = (USER_SESSION *) malloc(sizeof(*this_session));
	if (!this_session) {
	    panic ("%s: ran out of memory while allocating session\n",
	       prog_name);  
	}
    }

    template = &user_sessions[next_free_session];

    this_session->burst_list = template->burst_list;
    this_session->current_burst = template->burst_list;
    this_session->current_req = template->burst_list->req_list;
    this_session->total_num_reqs = template->total_num_reqs;
    
    u = call_arg.vp;
    u->uri_sess.vp = this_session;
    
    if (++next_free_session >= num_sessions) {
	next_free_session = 0;
    }
}

void
wsesslog_advance_to_next_burst(Sess *u)
{
    USER_SESSION *this_session;
    this_session = (USER_SESSION *) u->uri_sess.vp;

    if (this_session->current_burst != NULL) {
	this_session->current_burst = this_session->current_burst->next;
	this_session->current_req = this_session->current_burst->req_list;
    }
}

u_int
wsesslog_burst_len(Sess *u)
{
    USER_SESSION *this_session;
    this_session = (USER_SESSION *) u->uri_sess.vp;

    if (this_session->current_burst != NULL) {
	return this_session->current_burst->num_reqs;
    }
    else {
	return  0;
    }
}

Time
wsesslog_think_time_this_burst(Sess *u)
{
    USER_SESSION *this_session;
    this_session = (USER_SESSION *) u->uri_sess.vp;

    if (this_session->current_burst != NULL) {
	return this_session->current_burst->user_think_time;
    }
    else {
	return  0;
    }
}
    
static void
set_uri (Event_Type et, Call * c)
{
    Sess *u;
    USER_SESSION *this_session;
    
    assert (et == EV_CALL_NEW && object_is_call (c));

    u = SESS_PRIVATE_DATA (c->conn)->u;
    this_session = (USER_SESSION *) u->uri_sess.vp;

    if (this_session->current_req == NULL) {
	panic ("%s: internal error, requests ran past end of burst\n",
	       prog_name);
    }

    c->req.uri = this_session->current_req->uri;
    c->req.uri_len = this_session->current_req->uri_len;

    c->req.method = this_session->current_req->method;
    c->req.contents = this_session->current_req->contents;
    c->req.contents_len = this_session->current_req->contents_len;
    if (c->req.contents_len > 0) {
	call_append_request_header(c,this_session->current_req->extra_hdrs,
				   this_session->current_req->extra_hdrs_len);
    }

    this_session->current_req = this_session->current_req->next;

    if (DBG > 0) {
	fprintf (stderr,"%s: accessing URI `%s'\n", prog_name, c->req.uri);
    }
}

/* allocates memory for a REQ and assigns values to data members */

static REQ *
new_request(char *uristr)
{
    REQ *retptr;
    
    retptr = (REQ *) malloc(sizeof(*retptr));
    if (retptr == NULL || uristr == NULL) {
	panic ("%s: ran out of memory while parsing %s\n",
	       prog_name, param.wsesslog.file);  
    }
    memset(retptr, 0, sizeof (*retptr));
    retptr->uri = uristr;
    retptr->uri_len = strlen(uristr);
    retptr->method = HM_GET;
    return retptr;
}

static BURST *
new_burst(REQ *r)
{
    BURST *retptr;
    
    retptr = (BURST *) malloc(sizeof(*retptr));
    if (retptr == NULL) {
	panic ("%s: ran out of memory while parsing %s\n",
	       prog_name, param.wsesslog.file);  
    }
    memset(retptr, 0, sizeof (*retptr));
    retptr->user_think_time = wsesslog_default_user_think_time();
    retptr->req_list = r;
    return retptr;
}

/* read in session-defining logfile, create in-memory
   data structures from which to assign uri_s to calls */

static void
init_wlog (void)
{
    FILE *fp;
    Any_Type arg;
    int lineno, i, reqnum;
    USER_SESSION *sptr;
    char line[10000];	/* some uri's get pretty-damn long */
    char uri[10000];	/* some uri's get pretty-damn long */
    char method_str[1000];
    char this_arg[10000];
    char contents[10000];
    double think_time;
    int bytes_read;
    REQ *reqptr;
    BURST *bptr;
    char *from, *to, *parsed_so_far;
    int ch;
    int single_quoted, double_quoted, escaped, done;
    
    if ((fp = fopen(param.wsesslog.file,"r")) == NULL) {
	panic ("%s: can't open %s\n", prog_name, param.wsesslog.file);  
    }

    free_user_sessions_list = NULL;
    num_sessions = reqs_in_longest_session = 0;
    sptr = &user_sessions[0];
    
    for (lineno=1;fgets(line,sizeof(line),fp);lineno++) {
	if (line[0] == '#') {	
	    continue;		/* skip over comment lines */
	}
	if (sscanf(line,"%s %n",uri,&bytes_read) != 1) {
	    /* must be a session-delimiting blank line */
	    if (sptr->current_req != NULL) {
		sptr++;		/* advance to next session */
	    }
	    continue;
	}
	/* looks like a request-specifying line */
	reqptr = new_request(strdup(uri));
	
	if (sptr->current_req == NULL) {
	    num_sessions++;
	    if (num_sessions > MAX_USER_SESSIONS) {
		panic ("%s: too many sessions (%d) specified in %s\n",
		       prog_name, num_sessions, param.wsesslog.file);  
	    }
	    sptr->current_burst = sptr->burst_list = new_burst(reqptr);
	}
	else {
	    if (!isspace(line[0])) {
		/* this uri starts a new burst */
		sptr->current_burst->next = new_burst(reqptr);
		sptr->current_burst = sptr->current_burst->next;
	    }
	    else {
		sptr->current_req->next = reqptr;
	    }
	}
	/* do some common steps for all new requests */
	sptr->current_burst->num_reqs++;
	if (sptr->current_burst->num_reqs > MAX_BURST_LEN) {
	    panic ("%s: max burst lenght of %d exceeeded in %s\n",
		       prog_name, MAX_BURST_LEN, param.wsesslog.file);  
	}

	sptr->total_num_reqs++;
	if (sptr->total_num_reqs > reqs_in_longest_session) {
	    reqs_in_longest_session = sptr->total_num_reqs;
	}
	sptr->current_req = reqptr;

	/* parse rest of line to specify additional parameters
	   of this request and burst */
	parsed_so_far = line + bytes_read;
	while(sscanf(parsed_so_far," %s %n",this_arg,&bytes_read) == 1) {
	    if (sscanf(this_arg,"method=%s",method_str) == 1) {
		for (i=0;i<HM_LEN;i++) {
		    /* subtract 1 from strlen because of trailing space */
		    if (!strncmp(method_str,call_method_name[i],
			strlen(call_method_name[i]))) {
			sptr->current_req->method = i;
			break;
		    }
		}
		if (i == HM_LEN) {
		    panic ("%s: did not recognize method '%s' in %s\n",
			   prog_name, method_str, param.wsesslog.file);  
		}
	    }
	    else if (sscanf(this_arg,"think=%lf",&think_time) == 1) {
		sptr->current_burst->user_think_time = think_time;
	    }
	    else if (sscanf(this_arg,"contents=%s",contents) == 1) {
		/* this is tricky since contents might be a quoted
		   string with embedded spaces or escaped quotes.
		   We should parse this carefully from parsed_so_far */
		from = strchr(parsed_so_far,'=')+1;
		to = contents;
		single_quoted = FALSE;
		double_quoted = FALSE;
		escaped = FALSE;
		done = FALSE;
		while ((ch = *from++) != '\0' && !done) {
		    if (escaped == TRUE) {
			switch (ch) {
			  case 'n':
			    *to++ = '\n';
			    break;
			  case 'r':
			    *to++ = '\r';
			    break;
			  case 't':
			    *to++ = '\t';
			    break;
			  case '\n':
			    *to++ = '\n';
			    /* this allows an escaped newline to continue
			       the parsing to the next line. */
			    if (fgets(line,sizeof(line),fp) == NULL) {
				lineno++;
				panic ("%s: premature EOF seen in '%s'\n",
				       prog_name, param.wsesslog.file);  
			    }
			    parsed_so_far = from = line;
			    break;
			  default:
			    *to++ = ch;
			    break;
			}
			escaped = FALSE;
		    }
		    else if (ch == '"' && double_quoted) {
			double_quoted = FALSE;
		    }
		    else if (ch == '\'' && single_quoted) {
			single_quoted = FALSE;
		    }
		    else {
			switch (ch) {
			  case '\t':
			  case '\n':
			  case ' ':
			    if (single_quoted == FALSE &&
				double_quoted == FALSE) {
				done = TRUE;	/* we are done */
			    }
			    else {
				*to++ = ch;
			    }
			    break;
			  case '\\':		/* backslash */
			    escaped = TRUE;
			    break;
			  case '"':		/* double quote */
			    if (single_quoted) {
				*to++ = ch;
			    }
			    else {
				double_quoted = TRUE;
			    }
			    break;
			  case '\'':		/* single quote */
			    if (double_quoted) {
				*to++ = ch;
			    }
			    else {
				single_quoted = TRUE;
			    }
			    break;
			  default:
			    *to++ = ch;
			    break;
			}
		    }
		}
		*to = '\0';
		from--;		/* back up 'from' to '\0' or white-space */
		bytes_read = from - parsed_so_far;
		if ((sptr->current_req->contents_len = strlen(contents))!=0) {
		    sptr->current_req->contents = strdup(contents);
		    sprintf(sptr->current_req->extra_hdrs,
			    "Content-length: %d\r\n",
			    sptr->current_req->contents_len);
		    sptr->current_req->extra_hdrs_len =
		    			strlen(sptr->current_req->extra_hdrs);
		}
	    }
	    else {
		/* do not recognize this arg */
		panic ("%s: did not recognize arg '%s' in %s\n",
			   prog_name, this_arg, param.wsesslog.file);  
	    }
	    parsed_so_far+=bytes_read;
	}
    }
    fclose(fp);
    next_free_session = 0;

    if (DBG > 3) {
	fprintf (stderr,"%s: session list follows (max_reqs = %d):\n\n",
		prog_name, reqs_in_longest_session);
	
	for (i=0;i<num_sessions;i++) {
	    sptr = &user_sessions[i];
	    fprintf (stderr,"#session %d (total_reqs=%d):\n", i, sptr->total_num_reqs);
	    
	    for (bptr=sptr->burst_list;bptr;bptr=bptr->next) {
		for (reqptr=bptr->req_list, reqnum=0;reqptr;
		     		reqptr=reqptr->next, reqnum++) {

		    if (reqnum >= bptr->num_reqs) {
			panic ("%s: internal error detected in parsing %s\n",
				   prog_name, param.wsesslog.file);  
		    }
		    if (reqnum > 0) {
			fprintf(stderr,"\t");
		    }
		    fprintf(stderr,"%s", reqptr->uri);
		    if (reqnum == 0 &&
			bptr->user_think_time != wsesslog_default_user_think_time()) {
			fprintf(stderr," think=%0.2f",(double) bptr->user_think_time);
		    }
		    if (reqptr->method != HM_GET) {
			fprintf(stderr," method=%s",call_method_name[reqptr->method]);
		    }
		    if (reqptr->contents != NULL) {
			fprintf(stderr," contents='%s'",reqptr->contents);
		    }
		    fprintf(stderr,"\n");
		}
	    }
	    fprintf(stderr,"\n");
	}
    }

    arg.l = 0;
    event_register_handler(EV_SESS_NEW, (Event_Handler) set_sess, arg);
    event_register_handler(EV_SESS_DESTROYED, (Event_Handler) destroy_sess, arg);
    event_register_handler(EV_CALL_NEW, (Event_Handler) set_uri, arg);
}

Load_Generator uri_wsesslog =
  {
    "Generates URIs from a logfile, organized as user sessions",
    init_wlog,
    no_op,
    no_op
  };


