/*
	Copyright (C) 1998 Hewlett-Packard Company
*/
#ifndef wsesslog_h
#define wsesslog_h

extern size_t wsesslog_sess_private_data_offset;
extern Time wsesslog_default_user_think_time();

#define MAX_BURST_LEN	16

#define SESS_PRIVATE_DATA(c) \
  ((Sess_Private_Data *) ((char *)(c) + wsesslog_sess_private_data_offset))

enum
  {
    NON_PERSISTENT, PERSISTENT
  };

typedef struct Sess
  {
    struct Sess *next;		/* linked list of free sessions */
    u_int found_close_hdr : 1;	/* did server send us a close header? */
    u_int first_call : 1;	/* true if first call hasn't finished yet */
    u_int persistent : 1;	/* does sess have a persistent connection? */
    u_int failed : 1;		/* did session fail? */
    u_int dying : 1;		/* is session being destroyed? */
    Conn *conn[MAX_BURST_LEN];	/* connection(s) */
    u_int num_reqs_in_this_burst; /* # of requests created for this burst */
    u_int num_reqs_target;	/* target # of requests for this burst */
    u_int num_calls_done;	/* # of calls completed so far */
    u_int num_calls_destroyed;	/* # of calls destroyed so far */
    Timer *timer;		/* timer for session think time */
    Time born;			/* time this session was born */
    u_int sess_seq_no;		/* a session id */
    char *cookie;
    Any_Type uri_sess;	/* a way for uri module to get at its session data */
  }
Sess;

typedef struct Sess_Private_Data
  {
    Sess *u;
    int conn_num;		/* index into u->conn[] */
  }
Sess_Private_Data;

#endif /* wsesslog_h */
