/*
	Copyright (C) 1998 Hewlett-Packard Company
*/
#ifndef uri_wsesslog_h
#define uri_wsesslog_h

#include "wsesslog.h"

extern u_int wsesslog_num_calls_this_session (Sess *u);
extern u_int wsesslog_burst_len (Sess *u);
extern Time wsesslog_think_time_this_burst (Sess *u);
extern void wsesslog_advance_to_next_burst (Sess *u);
extern u_int wsesslog_num_calls_longest_session (void);
extern u_int wsesslog_num_calls_this_session (Sess *u);

#endif /* uri_wsesslog_h */
