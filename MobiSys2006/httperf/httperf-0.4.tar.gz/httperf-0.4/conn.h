/*
	Copyright (C) 1997 Hewlett-Packard Company
*/
#ifndef conn_h
#define conn_h

#include <sys/uio.h>

#include <httperf.h>
#include <timer.h>

struct Call;

typedef enum Conn_State
  {
    S_INITIAL,
    S_CONNECTING,
    S_CONNECTED,
    S_REPLY_STATUS,
    S_REPLY_HEADER,
    S_REPLY_DATA,
    S_REPLY_CHUNKED,
    S_REPLY_FOOTER,
    S_REPLY_DONE,
    S_CLOSING,
    S_FREE
  }
Conn_State;

typedef struct Conn
  {
    Object obj;

    Conn_State state;
    struct Conn *next;
    struct Call *first_owned;	/* list of calls owned by this connection */
    struct Call *sendq;		/* calls whose request needs to be sent */
    struct Call *sendq_tail;
    struct Call *recvq;		/* calls waiting for a reply */
    struct Call *recvq_tail;
    Timer *watchdog;

    struct
      {
	Time time_connect_start;	/* time connect() got called */
	u_int num_calls_completed;	/* # of calls that completed */
      }
    basic;			/* maintained by stat/stats_basic.c */

    size_t hostname_len;
    const char *hostname;	/* server's hostname (or 0 for default) */
    int port;			/* server's port (or -1 for default) */
    int	sd;			/* socket descriptor */
    int myport;			/* local port number or -1 */
    /* Since replies are read off the socket sequentially, much of the
       reply-processing related state can be kept here instead of in
       the reply structure: */
    size_t line_size;		/* # of bytes alloced for header/footer line */
    struct iovec line;		/* buffer used to parse reply headers */
    size_t content_length;	/* content length (or INF if unknown) */
    u_int has_body : 1;		/* does reply have a body? */
    u_int is_chunked : 1;	/* is the reply chunked? */
  }
Conn;

extern int max_num_conn;
extern Conn *conn;

extern void conn_init (void);
extern Conn *conn_new (void);
extern void conn_destroy (Conn *s);

#endif /* conn_h */
