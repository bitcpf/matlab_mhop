/*
              Copyright (C) 1997-1998 Hewlett-Packard Company
                         ALL RIGHTS RESERVED.
 
  The enclosed software and documentation includes copyrighted works
  of Hewlett-Packard Co. For as long as you comply with the following
  limitations, you are hereby authorized to (i) use, reproduce, and
  modify the software and documentation, and to (ii) distribute the
  software and documentation, including modifications, for
  non-commercial purposes only.
      
  1.  The enclosed software and documentation is made available at no
      charge in order to advance the general development of
      high-performance networking and computing products.
 
  2.  You may not delete any copyright notices contained in the
      software or documentation. All hard copies, and copies in
      source code or object code form, of the software or
      documentation (including modifications) must contain at least
      one of the copyright notices.
 
  3.  The enclosed software and documentation has not been subjected
      to testing and quality control and is not a Hewlett-Packard Co.
      product. At a future time, Hewlett-Packard Co. may or may not
      offer a version of the software and documentation as a product.
  
  4.  THE SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS".
      HEWLETT-PACKARD COMPANY DOES NOT WARRANT THAT THE USE,
      REPRODUCTION, MODIFICATION OR DISTRIBUTION OF THE SOFTWARE OR
      DOCUMENTATION WILL NOT INFRINGE A THIRD PARTY'S INTELLECTUAL
      PROPERTY RIGHTS. HP DOES NOT WARRANT THAT THE SOFTWARE OR
      DOCUMENTATION IS ERROR FREE. HP DISCLAIMS ALL WARRANTIES,
      EXPRESS AND IMPLIED, WITH REGARD TO THE SOFTWARE AND THE
      DOCUMENTATION. HP SPECIFICALLY DISCLAIMS ALL WARRANTIES OF
      MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
  
  5.  HEWLETT-PACKARD COMPANY WILL NOT IN ANY EVENT BE LIABLE FOR ANY
      DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES
      (INCLUDING LOST PROFITS) RELATED TO ANY USE, REPRODUCTION,
      MODIFICATION, OR DISTRIBUTION OF THE SOFTWARE OR DOCUMENTATION.
 
*/

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <httperf.h>
#include <call.h>
#include <event.h>
#include <conn.h>

static Call *free_call_list = 0;
static u_long next_id = 0;

Call *
call_new (Conn *s)
{
  size_t call_size;
  Any_Type arg;
  Call *c;

  call_size = object_type_size[OBJ_CALL];

  if (free_call_list)
    {
      c = free_call_list;
      free_call_list = c->next;
    }
  else
    {
      c = malloc (call_size);
      if (!c)
	{
	  fprintf (stderr, "%s.call_new: %s\n", prog_name, strerror (errno));
	  return 0;
	}
    }
  memset (c, 0, call_size);
  c->obj.type = OBJ_CALL;
  c->id = next_id++;
  c->conn = s;
  c->next = s->first_owned;
  s->first_owned = c;

  c->req.method = HM_GET;		/* default to get */
  c->req.version = param.http_version;

  arg.l = 0;
  event_signal (EV_CALL_NEW, (Object *)c, arg);

  return c;
}

void
call_destroy (Call *c)
{
  Call *prev, *p;
  Any_Type arg;

  for (prev = 0, p = c->conn->first_owned; p != c; prev = p, p = p->next)
    {
      if (!p)
	{
	  fprintf (stderr, "%s.call_destroy.%lu: is NOT on connection %p's "
		   "owned list!\n", prog_name, c->id, c->conn);
	  return;
	}
    }
  if (prev)
    prev->next = c->next;
  else
    c->conn->first_owned = c->next;

  event_signal (EV_CALL_DESTROYED, (Object *) c->conn, arg);

  c->next = free_call_list;
  free_call_list = c;
}
