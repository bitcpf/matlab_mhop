/*
 
              Copyright (C) 1997-1998 Hewlett-Packard Company
                         ALL RIGHTS RESERVED.
 
  The enclosed software and documentation includes copyrighted works
  of Hewlett-Packard Co. For as long as you comply with the following
  limitations, you are hereby authorized to (i) use, reproduce, and
  modify the software and documentation, and to (ii) distribute the
  software and documentation, including modifications, for
  non-commercial purposes only.
      
  1.  The enclosed software and documentation is made available at no
      charge in order to advance the general development of
      high-performance networking and computing products.
 
  2.  You may not delete any copyright notices contained in the
      software or documentation. All hard copies, and copies in
      source code or object code form, of the software or
      documentation (including modifications) must contain at least
      one of the copyright notices.
 
  3.  The enclosed software and documentation has not been subjected
      to testing and quality control and is not a Hewlett-Packard Co.
      product. At a future time, Hewlett-Packard Co. may or may not
      offer a version of the software and documentation as a product.
  
  4.  THE SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS".
      HEWLETT-PACKARD COMPANY DOES NOT WARRANT THAT THE USE,
      REPRODUCTION, MODIFICATION OR DISTRIBUTION OF THE SOFTWARE OR
      DOCUMENTATION WILL NOT INFRINGE A THIRD PARTY'S INTELLECTUAL
      PROPERTY RIGHTS. HP DOES NOT WARRANT THAT THE SOFTWARE OR
      DOCUMENTATION IS ERROR FREE. HP DISCLAIMS ALL WARRANTIES,
      EXPRESS AND IMPLIED, WITH REGARD TO THE SOFTWARE AND THE
      DOCUMENTATION. HP SPECIFICALLY DISCLAIMS ALL WARRANTIES OF
      MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
  
  5.  HEWLETT-PACKARD COMPANY WILL NOT IN ANY EVENT BE LIABLE FOR ANY
      DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES
      (INCLUDING LOST PROFITS) RELATED TO ANY USE, REPRODUCTION,
      MODIFICATION, OR DISTRIBUTION OF THE SOFTWARE OR DOCUMENTATION.
 
*/
/* Creates sessions at the fixed rate PARAM.RATE.  It assigns the
   session a persistent connection unless the limit on the number of
   persistent connections has been reached.  In the latter case, a
   series of non-persistent connections is used to complete the
   session.  */

#include <assert.h>
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <httperf.h>
#include <core.h>
#include <event.h>
#include <rate.h>
#include <conn.h>
#include <timer.h>

#define MAX_BURST_LEN	16

#define SESS_PRIVATE_DATA(c) \
  ((Sess_Private_Data *) ((char *)(c) + sess_private_data_offset))

enum
  {
    NON_PERSISTENT, PERSISTENT
  };

typedef struct Sess
  {
    struct Sess *next;		/* linked list of free sessions */
    u_int found_close_hdr : 1;	/* did server send us a close header? */
    u_int first_call : 1;	/* true if first call hasn't finished yet */
    u_int persistent : 1;	/* does sess have a persistent connection? */
    u_int failed : 1;		/* did session fail? */
    u_int dying : 1;		/* is session being destroyed? */
    Conn *conn[MAX_BURST_LEN];	/* connection(s) */
    u_int num_reqs_in_this_burst; /* # of requests created for this burst */
    u_int num_reqs_target;	/* target # of requests for this burst */
    u_int num_calls_done;	/* # of calls completed so far */
    u_int num_calls_destroyed;	/* # of calls destroyed so far */
    Timer *timer;		/* timer for session think time */
    Time born;			/* time this session was born */
    char *cookie;
  }
Sess;

typedef struct Sess_Private_Data
  {
    Sess *u;
    int conn_num;		/* index into u->conn[] */
  }
Sess_Private_Data;

static size_t sess_private_data_offset;

static int num_sessions_generated;
static int num_sessions_destroyed;
static int num_sessions_completed[2];
static int num_sessions_failed[2];
static Rate_Generator rg_sess;
static Sess *free_sess_list;
static Time call_time_sum[2];
static Time lifetime_sum[2];
static Time failtime_sum[2];
static u_int call_time_count[2];
static u_int (*sess_age_hist)[2];

static void
sess_destroy (Sess *u)
{
  Any_Type arg;
  Time now;
  int i;

  now = timer_now ();

  if (u->dying)
    return;
  u->dying = 1;

  if (DBG > 0)
    fprintf (stderr, "sess_destroy(u=%p)\n", u);

  if (u->num_calls_done >= param.wsess.num_calls && !u->failed)
    {
      lifetime_sum[u->persistent] += (now - u->born);
      ++num_sessions_completed[u->persistent];
    }
  else
    {
      failtime_sum[u->persistent] += (now - u->born);
      ++num_sessions_failed[u->persistent];

      ++sess_age_hist[u->num_calls_done][u->persistent];
    }

  if (u->timer)
    timer_cancel (u->timer);

  for (i = 0; i < param.burst_len; ++i)
    if (u->conn[i])
      core_close (u->conn[i]);
  if (u->cookie)
    free (u->cookie);

  arg.vp = u;
  event_signal (EV_SESS_DESTROYED, (Object *) 0, arg);

  u->next = free_sess_list;
  free_sess_list = u;

  if (++num_sessions_destroyed >= param.wsess.num_sessions)
    core_exit ();
}

static void
req_create (Sess *u, Conn *s)
{
  int i, to_create;
  Call *c;

  assert (s);

  /* Mimic browser behavior of fetching html object, then a couple of
     embedded objects: */

  to_create = 1;
  if (u->persistent && u->num_reqs_in_this_burst > 0)
    to_create = param.burst_len - u->num_reqs_in_this_burst;

  if (u->persistent)
    u->num_reqs_in_this_burst += to_create;

  for (i = 0; i < to_create; ++i)
    {
      c = call_new (s);
      if (!c)
	{
	  sess_destroy (u);
	  return;
	}

      if (u->cookie)
	{
	  assert (!c->req.extra_hdrs);
	  c->req.extra_hdrs = u->cookie;
	  c->req.extra_hdrs_len = strlen (u->cookie);
	}
      if (core_send (c) < 0)
	return;
    }
}

static void
sess_connect (Sess *u)
{
  int i, to_create, conn_num;
  Conn *s;

  to_create = 1;
  if (!u->persistent && u->num_reqs_in_this_burst > 0)
    to_create = param.burst_len - u->num_reqs_in_this_burst;

  for (i = 0; i < to_create; ++i)
    {
      s = conn_new ();
      if (DBG > 0)
	fprintf (stderr, "sess_connect: u=%p, s=%p\n", u, s);
      if (!s)
	{
	  sess_destroy (u);
	  return;
	}
      conn_num = 0;
      if (!u->persistent)
	conn_num = u->num_reqs_in_this_burst++;
      u->conn[conn_num] = s;
      SESS_PRIVATE_DATA(s)->conn_num = conn_num;
      SESS_PRIVATE_DATA(s)->u = u;
      if (core_connect (s) < 0)
	return;
    }
}

static void
user_think_time_expired (Timer *t, Any_Type arg)
{
  Sess *u = arg.vp;

  u->timer = 0;

  if (u->persistent)
    req_create (u, u->conn[0]);
  else
    sess_connect (u);
}

/* Create a new session.  If not all persistent connections are in use
   yet, assign it a persistent connection, otherwise use
   non-persistent connections to complete the session's request stream.
   */
static int
sess_create (Any_Type arg)
{
  Any_Type carg;
  Sess *u;

  if (num_sessions_generated++ >= param.wsess.num_sessions)
    return -1;

  if (free_sess_list)
    {
      u = free_sess_list;
      free_sess_list = u->next;
    }
  else
    {
      u = malloc (sizeof (*u));
      if (!u)
	{
	  fprintf (stderr, "%s.sess_create: %s\n",
		   prog_name, strerror (errno));
	  return -1;
	}
    }
  memset (u, 0, sizeof (*u));

  carg.vp = u;
  event_signal (EV_SESS_NEW, (Object *) 0, carg);

  /* Attempt to use persistent connection.  If server sends us a
     "Connection: close" header in response to the first call, we'll
     downgrade to non-persistent.  */
  u->persistent = 1;
  u->first_call = 1;
  u->num_reqs_target = param.burst_len;
  u->born = timer_now ();
  sess_connect (u);
  return 0;
}

/* A connection to the server has been established so issue the first
   (and possibly last) request on this connection.  */
static void
sess_connected (Event_Type et, Conn *s)
{
  Sess *u;

  assert (et == EV_CONN_CONNECTED && object_is_conn (s));

  u = SESS_PRIVATE_DATA(s)->u;
  req_create (u, s);
}

static void
sess_failed (Event_Type et, Conn *s)
{
  Sess *u;

  assert ((et == EV_CONN_FAILED || et == EV_CONN_TIMEOUT)
	  && object_is_conn (s));

  u = SESS_PRIVATE_DATA(s)->u;
  u->failed = 1;
  sess_destroy (u);

  assert (u->num_calls_done <= param.wsess.num_calls);
}

static void
sess_destroyed (Event_Type et, Conn *s)
{
  Time delta, now;
  Any_Type arg;
  int conn_num;
  Sess *u;

  assert (et == EV_CONN_DESTROYED && object_is_conn (s));

  now = timer_now ();

  u = SESS_PRIVATE_DATA(s)->u;
  conn_num = SESS_PRIVATE_DATA(s)->conn_num;

  assert (!u->conn[conn_num] || u->conn[conn_num] == s);
  u->conn[conn_num] = 0;

  if (u->dying)
    return;

  if (DBG > 0)
    fprintf (stderr, "sess_destroyed: u=%p, s=%p\n", u, s);

  if (u->persistent)
    sess_destroy (u);
  else
    {
      delta = now - s->basic.time_connect_start;
      call_time_sum[NON_PERSISTENT] += delta;
      ++call_time_count[NON_PERSISTENT];

      if (u->num_calls_destroyed >= param.wsess.num_calls)
	sess_destroy (u);
      else if (u->num_reqs_in_this_burst < param.burst_len)
	sess_connect (u);
      else if (u->num_calls_destroyed == u->num_reqs_target)
	{
	  u->num_reqs_in_this_burst = 0;
	  u->num_reqs_target += param.burst_len;
	  assert (!u->timer);
	  arg.vp = u;
	  u->timer = timer_schedule (user_think_time_expired, arg,
				     param.wsess.think_time);
	}
    }
}

static void
call_recv_hdr (Event_Type et, Call *c, Any_Type regarg, Any_Type call_arg)
{
  char *hdr, *start, *end;
  struct iovec *line;
  size_t len;
  Sess *u;
  int ch;

  assert (et == EV_CALL_RECV_HDR && object_is_call (c));

  u = SESS_PRIVATE_DATA (c->conn)->u;
  line = call_arg.vp;
  hdr = line->iov_base;
  ch = tolower (hdr[0]);

  switch (ch)
    {
    case 'c':
      if (line->iov_len == 17 && strcasecmp (hdr + 1, "onnection: close") == 0)
	u->found_close_hdr = 1;
      break;

    case 's':
      if (line->iov_len > 12
	  && strncasecmp (hdr + 1, "et-cookie: ", 11) == 0)
	{
	  start = hdr + 12;
	  end = strchr (start, ';');
	  if (!end)
	    end = hdr + line->iov_len;
	  len = end - start;
	  if (u->cookie)
	    {
	      if (DBG > 0)
		fprintf (stderr, "%s.wsess: can't handle more than one "
			 "cookie at a time, dropping existing one\n",
			 prog_name);
	      free (u->cookie);
	    }
	  u->cookie = malloc (len + 11);
	  if (!u->cookie)
	    {
	      u->failed = 1;
	      sess_destroy (u);
	      return;
	    }
	  memcpy (u->cookie, "Cookie: ", 8);
	  memcpy (u->cookie + 8, start, len);
	  memcpy (u->cookie + 8 + len, "\r\n", 2);
	  u->cookie[10 + len] = '\0';

	  if (DBG > 0)
	    fprintf (stderr, "%s: intercepted cookie `%s'\n",
		     prog_name, start);
	}
      break;

    default:
      break;
    }
}

static void
call_done (Event_Type et, Call *c)
{
  Time delta;
  Sess *u;

  assert (et == EV_CALL_RECV_STOP && object_is_call (c));

  u = SESS_PRIVATE_DATA (c->conn)->u;

  if (u->first_call && (u->found_close_hdr || c->reply.version < 0x10001))
    u->persistent = 0;

  u->first_call = 0;

  if (u->persistent)
    {
      delta = timer_now () - c->basic.time_send_start;
      call_time_sum[PERSISTENT] += delta;
      ++call_time_count[PERSISTENT];
    }

  if (param.failure_status && c->reply.status == param.failure_status)
    {
      u->failed = 1;
      sess_destroy (u);
      return;
    }
  ++u->num_calls_done;
  call_destroy (c);
}

static void
call_destroyed (Event_Type et, Conn *s)
{
  Any_Type arg;
  Sess *u;

  assert (et == EV_CALL_DESTROYED && object_is_conn (s));

  u = SESS_PRIVATE_DATA (s)->u;

  if (u->dying)
    return;

  ++u->num_calls_destroyed;

  if (u->persistent)
    {
      if (u->num_calls_destroyed >= param.wsess.num_calls)
	core_close (s);
      else if (u->num_reqs_in_this_burst < param.burst_len)
	req_create (u, s);
      else if (u->num_calls_destroyed == u->num_reqs_target)
	{
	  u->num_reqs_in_this_burst = 0;
	  u->num_reqs_target += param.burst_len;
	  assert (!u->timer);
	  arg.vp = u;
	  u->timer = timer_schedule (user_think_time_expired, arg,
				     param.wsess.think_time);
	}
    }
  else
    core_close (s);
}

static void
init (void)
{
  Any_Type arg;
  size_t size;

  if (param.burst_len > MAX_BURST_LEN)
    {
      fprintf (stderr, "%s: sorry, burst length is limited to %u\n",
	       prog_name, MAX_BURST_LEN);
      exit (1);
    }

  size = (param.wsess.num_calls + 1)*sizeof (sess_age_hist[0]);
  sess_age_hist = malloc (size);
  if (!sess_age_hist)
    {
      fprintf (stderr, "%s: out of memory\n", prog_name);
      exit (1);
    }
  memset (sess_age_hist, 0, size);

  sess_private_data_offset = object_type_size[OBJ_CONN];
  object_type_size[OBJ_CONN] += ALIGN (sizeof (Sess_Private_Data));

  rg_sess.tick = sess_create;
  rg_sess.arg.l = 0;

  arg.l = 0;
  event_register_handler (EV_CONN_CONNECTED, (Event_Handler) sess_connected,
			  arg);
  event_register_handler (EV_CONN_FAILED, (Event_Handler) sess_failed,
			  arg);
  event_register_handler (EV_CONN_TIMEOUT, (Event_Handler) sess_failed,
			  arg);
  event_register_handler (EV_CONN_DESTROYED, (Event_Handler) sess_destroyed,
			  arg);
  event_register_handler (EV_CALL_RECV_HDR,	(Event_Handler) call_recv_hdr,
			  arg);
  event_register_handler (EV_CALL_RECV_STOP,	(Event_Handler) call_done,
			  arg);
  event_register_handler (EV_CALL_DESTROYED,	(Event_Handler) call_destroyed,
			  arg);
}

static void
start (void)
{
  rate_generator_start (&rg_sess, param.rate, EV_SESS_DESTROYED);
}

static void
dump (void)
{
  u_int failed;
  Time avg[2] = {0.0, 0.0};
  int i, j;

  failed = param.wsess.num_sessions
      - (num_sessions_completed[PERSISTENT]
	 + num_sessions_completed[NON_PERSISTENT]);

  for (i = 0; i < NELEMS (avg); ++i)
    if (lifetime_sum[i] > 0.0)
      avg[i] = num_sessions_completed[i] / (test_time_stop - test_time_start);
    else
      avg[i] = 0.0;
  printf ("\nSess rate [sess/s]: total %.2f p %.2f (%u/%u) "
	  "non-p %.2f (%u/%u)\n",
	  avg[PERSISTENT] + avg[NON_PERSISTENT],
	  avg[PERSISTENT], num_sessions_completed[PERSISTENT],
	  (num_sessions_failed[PERSISTENT]
	   + num_sessions_completed[PERSISTENT]),
	  avg[NON_PERSISTENT], num_sessions_completed[NON_PERSISTENT],
	  (num_sessions_completed[NON_PERSISTENT]
	   + num_sessions_failed[NON_PERSISTENT]));

  for (i = 0; i < NELEMS (avg); ++i)
    if (num_sessions_completed[i] > 0)
      avg[i] = lifetime_sum[i] / num_sessions_completed[i];
    else
      avg[i] = 0.0;
  printf ("Sess lifetime [s]: p %.1f non-p %.1f\n",
	  avg[PERSISTENT], avg[NON_PERSISTENT]);

  for (i = 0; i < NELEMS (avg); ++i)
    if (num_sessions_failed[i] > 0)
      avg[i] = failtime_sum[i] / num_sessions_failed[i];
    else
      avg[i] = 0.0;
  printf ("Sess failtime [s]: p %.1f non-p %.1f\n",
	  avg[PERSISTENT], avg[NON_PERSISTENT]);

  for (j = 0; j < 2; ++j)
    {
      printf ("Sess failures: %sp",
	      (j == PERSISTENT) ? "    " : "non-");
      for (i = 0; i <= param.wsess.num_calls; ++i)
	printf (" %u", sess_age_hist[i][j]);
      putchar ('\n');
    }

  for (i = 0; i < NELEMS (avg); ++i)
    if (call_time_count[i] > 0)
      avg[i] = call_time_sum[i] / call_time_count[i];
    else
      avg[i] = 0.0;
  printf ("\nCall response time [ms]: p %.1f non-p %.1f\n",
	  1e3*avg[PERSISTENT], 1e3*avg[NON_PERSISTENT]);
}

Load_Generator wsess =
  {
    "creates session workload",
    init,
    start,
    no_op
  };

Stat_Collector wsess_stat =
  {
    "collects stats for session workload",
    no_op,
    no_op,
    no_op,
    dump
  };
