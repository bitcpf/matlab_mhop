/*
	Copyright (C) 1998 Hewlett-Packard Company
*/
#ifndef rate_h
#define rate_h

#include <httperf.h>
#include <timer.h>

typedef struct Rate_Generator
  {
    Time period;
    Time start;
    Time next_time;
    Any_Type arg;
    Timer *timer;
    int (*tick) (Any_Type arg);
    int done;
  }
Rate_Generator;

extern void rate_generator_start (Rate_Generator *rg, Time rate,
				  Event_Type completion_event);
extern void rate_generator_stop (Rate_Generator *rg);

#endif /* rate_h */
